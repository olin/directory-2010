<?php header("Location: ../"); die(); ?>
